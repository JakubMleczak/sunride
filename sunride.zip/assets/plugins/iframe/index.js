module.exports = require('./js')
