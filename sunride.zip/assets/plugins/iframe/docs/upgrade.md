## Upgrading to version 4

In version 4 support for IE 8-10 and Andriod 4.4 has been removed, if you still need this then please use [version 3](https://github.com/davidjbradshaw/iframe-resizer/tree/V3) of this library.

The callback methods have been renamed to onEvents, so for example `scrollCallback` is now called `onScroll`. This is to enable better integration with modern libraries such as React.
