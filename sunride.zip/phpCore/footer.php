<style>
    footer {
        position:static;
        margin-top:10%;
        
    }
    
</style>

<footer class="site-footer">
    
		<div class="container" >

			<div class="row">

				<div class="col-md-12">
                    <div class="uos">
                        <a href="https://www.sheffield.ac.uk/"><img src="demo/TEST/uos.png" alt=""></a>
                    </div>
                    <div class="shu">
                        <a href="https://www.shu.ac.uk/"><img src="demo/TEST/shu.png" alt=""></a>
                    </div>                    
					<div class="footer-logo">
						<a href="http://ssi.group.shef.ac.uk/"><img src="demo/TEST/SSI.png" alt=""></a>
					</div>
                    
					<p>Copyright &copy;. <a href="#">SunrIde</a>. All Rights Reserved.</p>


					<div class="social-list">
						<ul id="list">
							<li><a href="https://www.facebook.com/shefsunride/" target="_blank" class="fa fa-facebook"></a></li>
							<li><a href="https://twitter.com/team_sunride?lang=en" target="_blank"class="fa fa-twitter"></a></li>
							<li><a href="https://www.linkedin.com/company/team-sunride" target="_blank" class="fa fa-linkedin"></a></li>

						</ul>
					</div>

				</div>

			</div>

		</div>

	</footer>