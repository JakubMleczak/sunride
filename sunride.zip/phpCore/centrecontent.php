<div class="row">
      
<div class="col-md-12"><hr>
        <h3 class="" style="color:white;">
        <span> <?php echo $title ?></span>
        </h3>
      <p style="color:white;text-align:justify;" class="lead">  <?php echo $info ?> </p>
    </div>
</div>
