<div class="row">
                                
    <div class="col-md-4">
        <img src="<?php $img ?>">
    </div>
    
    <div class="col-md-8"><hr>
        <h3 class="" style="color:white;">
        <span><?php $title ?></span>
        </h3>
      <p style="color:white;text-align:justify;" class="lead"> <?php $info ?> </p>
    </div>

</div>