<header class="site-header" style="overflow:hidden; padding:0px;margin:0px;min-height: 1%">

	<div class="header-inner">

		<div class="container">

			<div class="row">

				<div class="header-table col-md-12">

					<div class="brand">
						<a href="#">
							<img src="demo/img/logo.png" >
						</a>
					</div>

					<nav class="main-nav">
				<a href="#" class="nav-toggle"></a>
				<ul class="nav">
				<li><a href="index.php">Home</a>
				    <span class="sub-toggle"></span>
						
					    <ul>
						    <li><a href="index.php#about">About Us</a></li>
							<li><a href="index.php#sponsor">Sponsors</a></li>
							<li><a href="index.php#contact">Get In Touch </a></li>
						</ul>
				</li>
				<!--<li>
				    <a href="currentprojects.php#agenda">Current Projects</a>
				    <span class="sub-toggle"></span>
						
					    <ul>
							<li><a href="currentprojects.php#research">Current Research</a></li>
						    <li><a href="currentprojects.php#agenda">Agenda</a></li>
							<li><a href="currentprojects.php#progress">Progress </a></li>
						</ul>				    
				</li>-->
                <li>
						<a href="#">
							Meet Our Team
						<span class="sub-toggle"></span>
						</a>
					    <ul>
					        <!--<li><a href="2021.php">SunrIde 2021</a></li>-->
						    <li><a href="2020.php">SunrIde 2020</a></li>
							<li><a href="2019.php">SunrIde 2019</a></li>
							<li><a href="2018.php">SunrIde 2018</a></li>
							<li><a href="index.php#contact">Join Us </a></li>
						</ul>
				</li>
				<li>
				    <a href="rockets.php">Our Rockets</a>
				    <span class="sub-toggle"></span>
						
					    <ul>
						    <li><a href="sunfire.php">SunFire 2020/21 </a></li>
						    <li><a href="gagarin.php">Karman Alpha 2021/22</a></li>
							<li><a href="vesna.php">Vesna 2020/21</a></li>
							<li><a href="jr.php">Sunride Jr 2019/20 </a></li>
							<li><a href="helen.php">Helen 2018/19 </a></li>
							<li><a href="amy.php">Amy 2017/18 </a></li>
						</ul>				    
				</li>
              	<li>
							    <a href="#">
									University profile
								<span class="sub-toggle"></span>
								</a>
								<ul>
									<li><a href="uos.php">University of Sheffield</a></li>
									<li><a href="shu.php">Sheffield Hallam University</a></li>
								</ul>
				</li>
				    <li>
						<a href="#">
							Media
						<span class="sub-toggle"></span>
						</a>
					    <ul>
						    <li><a href="gallery.php">Gallery</a></li>
							<li><a href="models.php">3D Models</a></li>
							<li><a href="lit.php">Literature</a></li>							
							<li><a href="blog.html">UKRA</a></li>
						</ul>
				</li>
              	<li><a href="news.html">News</a></li>
                
                
						</ul>
					</nav>

				</div>

			</div>

		</div>

	</div>


</header>