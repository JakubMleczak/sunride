<header class="site-header" style="overflow:hidden; padding:0px;margin:0px;min-height: 1%">

	<div class="header-inner">

		<div class="container">

			<div class="row">

				<div class="header-table col-md-12">

					<div class="brand">
						<a href="#">
							<img src="demo/img/logosmall.png">
						</a>
					</div>

					<nav class="main-nav">
						<a href="#" class="nav-toggle"></a>
						<ul class="nav">
							<li><a href="index.php">Home</a>

							</li>

							<li>
								<a href="rockets.php">Our Rockets</a>
								<span class="sub-toggle"></span>

								<ul>
									<li><a href="sunfire.php">SunFire 2020/21 </a></li>
									<li><a href="gagarin.php">Karman Alpha 2021/22</a></li>
									<li><a href="vesna.php">Vesna 2020/21</a></li>
									<li><a href="jr.php">Sunride Jr 2019/20 </a></li>
									<li><a href="helen.php">Helen 2018/19 </a></li>
									<li><a href="amy.php">Amy 2017/18 </a></li>
								</ul>
							</li>
							<li>
								<a href="#">
									News
								</a>
							</li>
							<li>
								<a href="#">
									Society
								</a>
							</li>
							<li><a href="news.html">Gallery</a></li>
							<li><a href="news.html">Partners</a></li>
							<li><a href="news.html">Sponsors</a></li>
							<li><a href="news.html">About</a></li>
							<li>
								<a href="#">
									Dark Mode
								</a>

							</li>


						</ul>
					</nav>

				</div>

			</div>

		</div>

	</div>


</header>