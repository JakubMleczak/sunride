<div class="col-lg-12"><hr style="margin:0%;"><br><br><br>
                                    
    <div class="col-lg-9" style="background-color:white;border-radius: 25px;">
        <span></span><br>
        <span>date posted: <i><?php echo $date ?></i></span><br><br>
        <img src="<?php echo $img ?>" style="position:absolute;border-radius: 100px;"><br><br>
        <span ><?php echo $info ?></span>
        <br><br>
    </div>
    <div class="col-lg-1">
        
    </div>
    <div class="col-lg-2">
        <img src="<?php echo $pic ?>" style="position:absolute;width:150px;height:150px;border-radius: 100px;">
    </div>
    
</div>