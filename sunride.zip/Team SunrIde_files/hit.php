<!DOCTYPE html>
<html>
<head>
    <title>Error 404 - Page Not Found</title>
</head>
<body>
    <h1>Error 404 - Page Not Found</h1>
</body>
</html>
